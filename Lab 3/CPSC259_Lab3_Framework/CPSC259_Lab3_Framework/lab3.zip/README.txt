1. Author:		Geoff Goodwin-Wilson, Mansur He
   Student #s:		30215164, 44638154
   CS Accounts:		s2v0b, p5h0b
   Date:		October 30th, 2016

2. We tested our program for correctness by running the unit tests provided to us.
3. We found it challenging to meet every unit test for each function.  We overcame this challenge
by trying various different methods of achieving the same solution.  Eventually, we were able to find the
best method for each function.
4. about 3 each
5. 50%/50%
6. n/a
We have read and understood the plagiarism policies at https://www.cs.ubc.ca/our-department/administration/policies/collaboration and we understand that no excuse for plagiarism will be accepted, including any listed in http://www.cs.ubc.ca/~tmm/courses/cheat.html
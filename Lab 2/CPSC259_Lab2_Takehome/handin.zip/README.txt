Names:			  LuFei Liu, Muchen He
Student ID:		14090154, 44638154
CS Accounts:	d9l0b, p5h0b
Date:         October 9, 2016

The output of our program is compared thoroughly with the expected results given to us.
We ran the program through the three tests: "perfect_match", "short_sample", and "long_sample",
the results of our program matched perfectly with the expected.

The challenges include making sure we are not looking at wrong memory location, so part of our
effort is to ensure that all operations are dereferenced properly. Another challenge is debugging,
since we're working with pointers, it was harder to debug to see if there was certain part of the
code that caused dereferencing places that are "out of bound".

We spent a collective of about 4 hours on this lab. With roughly 50%/50% contribution.

We have read and understood the plagiarism policies at
https://www.cs.ubc.ca/our-department/administration/policies/collaboration and we understand that
no excuse for plagiarism will be accepted, including any listed in
http://www.cs.ubc.ca/~tmm/courses/cheat.html".
